var request=require('supertest');
var app=require('../../app');
var decribe = require('mocha').describe;
decribe('create device',function(){
        it('should create a device',function(){
            var deviceCreateCommand=`CREATE /devices/n
            content-type : application/json/n/n
            {"type" : "COMPUTER", "name" : "A1"}`;

            request(app).post('/ajiranet/process').send(deviceCreateCommand).expect(200)
        })

})