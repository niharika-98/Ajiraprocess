const pathAlgorithm = {};
var dist = {};
var pred = {};
var path = [];
pathAlgorithm.findPath = (src, dest, connectionMap, deviceArr) => {
    if (pathAlgorithm.bfs(src, dest, connectionMap, deviceArr)) {
        console.log(connectionMap);
        var node = dest;
        while (node != src) {
            path.push(node);
            node = pred[node];
        }
        path.push(node);
        console.log(path);

    }
    return path;
}

pathAlgorithm.bfs = (src, dest, connectionMap, deviceArr) => {
    console.log(src, dest, connectionMap, deviceArr);
    var visited = {};
    var queue = [];
    var source;
    var found = 0;
    path = [];
    deviceArr.forEach(device => {
        visited[device.name] = false;
    });
    queue.push(src);
    dist[src] = 0;
    while (queue.length != 0) {
        source = queue.shift();
        visited[source] = true;
        console.log(queue, source, connectionMap[source])
        for (i = 0; i < connectionMap[source].length; i++) {
            device = connectionMap[source][i];

            if (visited[device] == false) {
                visited[device] = true;
                queue.push(device);
                dist[device] = dist[source] + 1;
                pred[device] = source;
                if (device == dest) {
                    console.log(pred);
                    return true;
                }
            }
        }
    }
}


module.exports = pathAlgorithm;