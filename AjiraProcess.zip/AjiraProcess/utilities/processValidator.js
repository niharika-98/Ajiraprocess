const createValidator={}

createValidator.validateDeviceType=(device)=>{
    if(JSON.parse(device).type=='COMPUTER'|| JSON.parse(device).type=='REPEATER'){
        return true;
    }else{
        return false;
    }
}
createValidator.validateDeviceName=(deviceArr,device)=>{
    console.log(deviceArr,device);
const index=deviceArr.findIndex((x)=>x.name==device.name);
if(index==-1){
    return true;
}else{
  return  false;
}
}

createValidator.connection=(connection)=>{
    
    var index=connection.targets.findIndex((x)=>x==connection.source);
    if(index==-1){
        return true;
    }else{
        return false;
    }
}

createValidator.areAlreadyConnected=(connectionMap,source,target)=>{
    if(connectionMap[source].findIndex((x)=>x==target)==-1){
        return true;
    }
    else{
        return false;
    }
}

createValidator.checkInteger=(strength)=>{
    console.log(parseInt(strength.value))
    console.log(isNaN(parseInt(strength.value)))
  if(!isNaN(parseInt(strength.value))){
      return true;
  }else{
      return false;
  }
}

module.exports=createValidator;