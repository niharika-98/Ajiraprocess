const url = require('url');
const querystring = require('querystring');
var createServiceValidator = require('../utilities/processValidator');
var pathAlgorithm = require('../utilities/pathAlgorithms');

var createService = {};
var deviceArr = [];
var connectionMap = {};
var strengthArr = {};

createService.devies = (createRequest) => {
    var requestArr = createRequest.split('\n');
    if (createServiceValidator.validateDeviceType(requestArr[3])) {
        if (createServiceValidator.validateDeviceName(deviceArr, JSON.parse(requestArr[3]))) {
            deviceArr.push(JSON.parse(requestArr[3]));
            strengthArr[JSON.parse(requestArr[3]).name] = 5;
            connectionMap[JSON.parse(requestArr[3]).name.trim()] = [];
            return { code: 200, msg: `Successfully added ${JSON.parse(requestArr[3]).name}` };
        }
        else {
            return { code: 400, msg: `Device ${JSON.parse(requestArr[3]).name} already exist` };
        }
    }
    else {
        return { code: 400, msg: `type ${JSON.parse(requestArr[3]).type} is not supported` };
    }

}


createService.connections = (connectRequest) => {
    var requestArr = connectRequest.split('\n');
    if (JSON.parse(requestArr[3])['source'] == null || JSON.parse(requestArr[3])['targets'] == null) {

        return { code: 400, msg: `Invalid command syntax` };
    }
    if (createServiceValidator.validateDeviceName(deviceArr, { name: JSON.parse(requestArr[3])['source'] })) {
        return { code: 400, msg: `Node ${JSON.parse(requestArr[3])['source']} not found` };
    }
    if (createServiceValidator.connection(JSON.parse(requestArr[3]))) {
        for (i = 0; i < JSON.parse(requestArr[3]).targets.length; i++) {
            target = JSON.parse(requestArr[3]).targets[i];
            console.log(JSON.parse(requestArr[3]).source, target, connectionMap);
            if (!createServiceValidator.areAlreadyConnected(connectionMap, JSON.parse(requestArr[3]).source, target)) {
                return { code: 400, msg: `Devices are already connected` };
            }
            connectionMap[JSON.parse(requestArr[3]).source.trim()].push(target);
            connectionMap[target].push(JSON.parse(requestArr[3]).source);
            console.log(JSON.parse(requestArr[3]).source, target, connectionMap, connectionMap[JSON.parse(requestArr[3]).source.trim()]);
        };

        return { code: 200, msg: `Successfully connected` };

    } else {
        return { code: 400, msg: `Cannot connect device to itself` };
    }
}


createService.fetchDevices = () => {
    return { code: 200, "devices": deviceArr }
}

createService.findPath = (requestBody) => {
    var parsedUrl = url.parse(requestBody);
    console.log(parsedUrl.query);
    var parsedQs = querystring.parse(parsedUrl.query);
    var path;
    var msg;
    console.log(parsedQs);
    if (parsedQs.to == parsedQs.from) {
        return { code: 200, msg: `Route is ${parsedQs.to} -> ${parsedQs.from}` };
    }
    if (createServiceValidator.validateDeviceName(deviceArr, { name: parsedQs.to })) {
        return { code: 400, msg: `Node ${parsedQs.to} not found` };
    }
    if (createServiceValidator.validateDeviceName(deviceArr, { name: parsedQs.from })) {
        return { code: 400, msg: `Node ${parsedQs.from} not found` };
    }
    if (createService.isRepeater(parsedQs.from, parsedQs.to)) {
        return { code: 400, msg: `Route cannot be calculated with repeater` };
    }

    path = pathAlgorithm.findPath(parsedQs.from, parsedQs.to, connectionMap, deviceArr);
    if (path.length != 0) {
        message = "Route is ";
        for (i = path.length - 1; i >= 0; i--) {

            message += path[i];
            if (i > 0)
                message += '->';
        }
        return { code: 200, msg: message }
    }
    else {
        return { code: 404, msg: "Route not found" };
    }
}



createService.modifyStrength = (requestBody) => {
    var requestArr = requestBody.split('\n');
    var commandArray = requestArr[0].split(' ');
    const deviceName = commandArray[1].split('/')[2];
    console.log(commandArray[1].split('/'));
    if (!createServiceValidator.validateDeviceName(deviceArr, { name: deviceName })) {
        console.log(requestArr[3]);
        if (createServiceValidator.checkInteger(JSON.parse(requestArr[3]))) {
            strengthArr[deviceName] = parseInt(JSON.parse(requestArr[3]).value);
            return { code: 200, msg: `Successfully defined strength` };
        } else {
            return { code: 400, msg: `value should be an integer` };
        }
    }
    else {
        return { code: 404, msg: `Device not found` };
    }
}




createService.isRepeater = (source, destination) => {
    for (i = 0; i < deviceArr.length; i++) {
        if (deviceArr[i].name == source) {
            if (deviceArr[i].type == 'REPEATER') {
                return true;
            }
        }
        if (deviceArr[i].name == destination) {
            if (deviceArr[i].type == 'REPEATER') {
                return true;
            }
        }
    }
    return false;
}
module.exports = createService;