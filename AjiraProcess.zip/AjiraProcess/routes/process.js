var express = require('express');
var router = express.Router();
var createService = require('../services/create');
var reqBody;
var responseBody;

router.post('/process', function (req, res, next) {
    reqBody = req.body
    var queryRequest = reqBody.split('\n');
    var val = reqBody.split('\n')[0];
    var command = val.split(' ')[0].trim();
    val = val.split(' ')[1].trim();
    console.log(queryRequest)
    if (command == 'CREATE' && val.trim() === "/devices" && queryRequest.length == 4) {
        responseBody = createService.devies(reqBody);
        res.status(responseBody.code);
        res.json({ "msg": responseBody.msg });
    } else if (command == 'CREATE' && val.trim() === "/connections" && queryRequest.length == 4) {
        responseBody = createService.connections(reqBody);
        res.status(responseBody.code);
        res.json({ "msg": responseBody.msg });
    } else if (command == 'FETCH' && val.trim() === "/devices") {
        responseBody = createService.fetchDevices(reqBody);
        res.status(responseBody.code);
        res.json({ "devices": responseBody.devices });
    }

    else if (command == 'FETCH' && val.trim().includes("/info-routes")) {
        if (val.includes("from") && val.includes("to")) {
            responseBody = createService.findPath(reqBody);
            res.status(responseBody.code);
            res.json({ "msg": responseBody.msg });
        }
        else {
            res.status(200);
            res.json({ "msg": "Invalid Request" });
        }
    }
    else if (command == 'MODIFY' && val.trim().includes("/devices") && val.trim().includes("/strength") && queryRequest.length == 4) {
        responseBody = createService.modifyStrength(reqBody);
        res.status(responseBody.code);
        res.json({ "msg": responseBody.msg });
    }
    else {
        res.status(400);
        res.json({ "msg": "Invalid command" });
    }

});

module.exports = router;